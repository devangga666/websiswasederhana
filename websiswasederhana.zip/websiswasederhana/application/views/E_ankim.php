<!DOCTYPE html>
<head>
    <title>Edit Data Siswa</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
  body {
    background-image:url(https://scontent.fcgk9-2.fna.fbcdn.net/v/t31.0-8/16700597_388972374810824_1801649612069272450_o.jpg?_nc_cat=101&ccb=3&_nc_sid=6e5ad9&_nc_eui2=AeFMIr_J5Rc-rjrFjsTdUrhrbjjTbIKBwppuONNsgoHCmhXU5lwinniZl3dK6SWia9cnkjtJTZojGXBuAwEvdWY1&_nc_ohc=5-m0widiJo0AX_kcLnZ&_nc_ht=scontent.fcgk9-2.fna&oh=914c6c19f5f42d3262f3ce8ccdc6d36a&oe=60615D04);
    background-repeat:no-repeat;
    background-size:cover;
  }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('Control/indexadmin'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="<?= base_url('Control/logout'); ?>">Logout</a>
      </li>
    </ul>
  </div>
</nav>
</br>
</br>
</br>
</br>
<div class="container">
<div class="card text-left">
  <div class="card-header">
    <ul class="nav nav-pills card-header-pills">
      <li class="nav-item">
      </li>
    </ul>
  </div>
  <div class="card-body">
  </div>
    <?php foreach ($ankim as $a){ ?>
    <form action="<?php echo base_url(). 'Control/update_ankim'; ?>" method="post">
    <table class="table table-bordered table-stripped">
    <thead>
        <tr>
            <td>Nama</td>
            <td>
            <input type="hidden" name="idankim" value="<?php echo $a->idankim ?>">
            <input type="text" name="namaankim" class="form-control" value="<?php echo $a->namaankim ?>">
            </td>
            </tr>
        <tr>
        <div class="form-grup">
        <td><label>Kelas</label></td>
        <td>
        <select name="kelasankim" class="form-control">
        <option value="X" <?= $a->kelasankim == 'X' ? 'selected' : '' ; ?>>X</option>
        <option value="XI" <?= $a->kelasankim == 'XI' ? 'selected' : '' ; ?>>XI</option>
        <option value="XII" <?= $a->kelasankim == 'XII' ? 'selected' : '' ; ?>>XII</option>
        </select>
        </div>
        </td>
        </tr>
        <tr>
        <div class="form-grup">
        <td><label>Jurusan</label></td>
        <td>
        <select name="jurusanankim" class="form-control">
        <option value="RPL" <?= $a->jurusanankim == 'RPL' ? 'selected' : '' ; ?>>RPL</option>
        <option value="TKJ" <?= $a->jurusanankim == 'TKJ' ? 'selected' : '' ; ?>>TKJ</option>
        <option value="Perkes" <?= $a->jurusanankim == 'Perkes' ? 'selected' : '' ; ?>>Perkes</option>
        <option value="Ankim" <?= $a->jurusanankim == 'Ankim' ? 'selected' : '' ; ?>>Ankim</option>
        <option value="Farmasi" <?= $a->jurusanankim == 'Farmasi' ? 'selected' : '' ; ?>>Farmasi</option>
        </select>
        </div>
        </td>
        </tr>
        <td>NIK</td>
        <td>
        <input type="text" name="nikankim" class="form-control" value="<?php echo $a->nikankim ?>">
            </td>
            </tr>
            <td>Alamat</td>
            <td>
            <input type="text" name="alamatankim" class="form-control" value="<?php echo $a->alamatankim ?>">
            </td>
            </tr>
        <tr>
        <td></td>
            <td>
                <button type="submit" class="btn btn-primary">Kirim</button>
                <a class="btn btn-primary" href="<?= base_url('Control/ankim'); ?>">Kembali</a>
            </td>
        </tr>
        </table>
        </form>
        </div>
        <?php } ?>
</body>
</html>