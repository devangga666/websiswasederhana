<!DOCTYPE html>
<head>
<title>Welcome</title>
<style>
  body {
    background-image:url(https://scontent.fcgk9-2.fna.fbcdn.net/v/t31.0-8/16700597_388972374810824_1801649612069272450_o.jpg?_nc_cat=101&ccb=3&_nc_sid=6e5ad9&_nc_eui2=AeFMIr_J5Rc-rjrFjsTdUrhrbjjTbIKBwppuONNsgoHCmhXU5lwinniZl3dK6SWia9cnkjtJTZojGXBuAwEvdWY1&_nc_ohc=5-m0widiJo0AX_kcLnZ&_nc_ht=scontent.fcgk9-2.fna&oh=914c6c19f5f42d3262f3ce8ccdc6d36a&oe=60615D04);
    background-repeat:no-repeat;
    background-size:cover;
  }
</style>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('Control/indexadmin'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li>
        <a class="nav-link"  href="<?= base_url('Control/logout')?>">Logout</a>
    </li>
    </ul>
  </div>
</nav>
</br>
</br>
</br>
</br>
<div class="container">
<div class="card text-center">
<div class="card" style="center">
  <div class="card-body">
  </br>
  </br>
    <h5 class="card-title"><b>
    Selamat Datang Admin
    </br>
     Terima Kasih Sudah Berkunjung
     </b></h5>
    <p class="card-text">
    Web Ini Masih Dalam Masa Percobaan
    </p>
    </br>
    </br>
    </br>
    </br>

    <center><img src="https://pbs.twimg.com/profile_images/518215471561060352/r-ji9Tii.jpeg"></center>
    </br>
    </br>
    <center><a href="<?= base_url('Control/rpl') ?>" class="btn btn-secondary">Edit Data Siswa Jurusan Rekayasa Perangkat Lunak</a><center>
    </br>
    <center><a href="<?= base_url('Control/tampil_tkj') ?>" class="btn btn-secondary">Edit Data Siswa Jurusan Teknik Komputer Jaringan</a><center>
    </br>
    <center><a href="<?= base_url('Control/perkes') ?>" class="btn btn-secondary">Edit Data Siswa Jurusan Perawat Kesehatan</a><center>
    </br>
    <center><a href="<?= base_url('Control/ankim') ?>" class="btn btn-secondary">Edit Data Siswa Jurusan Analisis Kimia</a><center>
    </br>
    <center><a href="<?= base_url('Control/farmasi') ?>" class="btn btn-secondary">Edit Data Siswa Jurusan Farmasi</a><center>
    </br>
  </div>
</div>
</div>
</div>
</body>
</html>