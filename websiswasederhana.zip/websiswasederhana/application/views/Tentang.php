<!DOCTYPE html>
<head>
<title>Tentang Website</title>
<style>
img{
    width:200px;
    height:230px;
}
  body {
    background-image:url(https://scontent.fcgk9-2.fna.fbcdn.net/v/t31.0-8/16700597_388972374810824_1801649612069272450_o.jpg?_nc_cat=101&ccb=3&_nc_sid=6e5ad9&_nc_eui2=AeFMIr_J5Rc-rjrFjsTdUrhrbjjTbIKBwppuONNsgoHCmhXU5lwinniZl3dK6SWia9cnkjtJTZojGXBuAwEvdWY1&_nc_ohc=5-m0widiJo0AX_kcLnZ&_nc_ht=scontent.fcgk9-2.fna&oh=914c6c19f5f42d3262f3ce8ccdc6d36a&oe=60615D04);
    background-repeat:no-repeat;
    background-size:cover;
  }
</style>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="<?= base_url('Control/index'); ?>">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
      <a class="nav-link" href="<?= base_url('Control/tentang'); ?>">Tentang Website</a>
      </li>
    </ul>
  </div>
</nav>
</br>
</br>
</br>
<div class="container">
<div class="card text-center">
<div class="card" style="center">
  <div class="card-body">
    <h5 class="card-title"><b>Tentang Website</b></h5>
    <p class="card-text">Website Ini Di Buat Oleh 
    </br> <b>Devangga Rizki Naraya</b></br>
    Hanya Untuk Pembelajaran CI 
    </p>
    <center><img src="https://scontent.fcgk8-2.fna.fbcdn.net/v/t1.6435-9/fr/cp0/e15/q65/155259222_910671876410287_5258872261762742234_n.jpg?_nc_cat=109&ccb=3&_nc_sid=58c789&efg=eyJpIjoidCJ9&_nc_eui2=AeFeKCzTJsj8sl8y0A9wwU59kYOmz2sBc4SRg6bPawFzhP0GsIEQ7LmdMgAy7Lnb06kfRJppuzbYoIVjYwvkT9gA&_nc_ohc=78CAUk8OqDkAX9yhj4Y&_nc_ht=scontent.fcgk8-2.fna&tp=14&oh=51ccee047bb33ca4c63587314c4b70d5&oe=6060E9D7"></center>
    </br>
    <a href="<?= base_url('Control/index') ?>" class="btn btn-primary">Kembali Ke Beranda</a>
  </div>
</div>
</div>
</div>
</body>
</html>