-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Mar 16, 2021 at 08:47 AM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 7.3.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coba`
--

-- --------------------------------------------------------

--
-- Table structure for table `ankim`
--

CREATE TABLE `ankim` (
  `idankim` int(11) NOT NULL,
  `namaankim` varchar(255) NOT NULL,
  `kelasankim` enum('X','XI','XII','') NOT NULL,
  `jurusanankim` enum('RPL','TKJ','Perkes','Ankim','Farmasi') NOT NULL,
  `nikankim` varchar(255) NOT NULL,
  `alamatankim` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `farmasi`
--

CREATE TABLE `farmasi` (
  `idd` int(11) NOT NULL,
  `namaid` varchar(255) NOT NULL,
  `kelasid` enum('X','XI','XII','') NOT NULL,
  `jurusanid` enum('RPL','TKJ','Perkes','Ankim','Farmasi') NOT NULL,
  `nikid` varchar(255) NOT NULL,
  `alamatid` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `perkes`
--

CREATE TABLE `perkes` (
  `idperkes` int(11) NOT NULL,
  `namaa` varchar(255) NOT NULL,
  `kelass` enum('X','XI','XII','') NOT NULL,
  `jurusann` enum('RPL','TKJ','Perkes','Ankim','Farmasi') NOT NULL,
  `nikk` varchar(255) NOT NULL,
  `alamatt` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tkj`
--

CREATE TABLE `tkj` (
  `idid` int(11) NOT NULL,
  `idnama` varchar(255) NOT NULL,
  `idkelas` enum('X','XI','XII','') NOT NULL,
  `idjurusan` enum('RPL','TKJ','Perkes','Ankim','Farmasi') NOT NULL,
  `idnik` varchar(255) NOT NULL,
  `idalamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tutor`
--

CREATE TABLE `tutor` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `kelas` enum('X','XI','XII','') NOT NULL,
  `jurusan` enum('RPL','TKJ','Perkes','Ankim','Farmasi') NOT NULL,
  `nik` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ankim`
--
ALTER TABLE `ankim`
  ADD PRIMARY KEY (`idankim`);

--
-- Indexes for table `farmasi`
--
ALTER TABLE `farmasi`
  ADD PRIMARY KEY (`idd`);

--
-- Indexes for table `perkes`
--
ALTER TABLE `perkes`
  ADD PRIMARY KEY (`idperkes`);

--
-- Indexes for table `tkj`
--
ALTER TABLE `tkj`
  ADD PRIMARY KEY (`idid`);

--
-- Indexes for table `tutor`
--
ALTER TABLE `tutor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ankim`
--
ALTER TABLE `ankim`
  MODIFY `idankim` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `farmasi`
--
ALTER TABLE `farmasi`
  MODIFY `idd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `perkes`
--
ALTER TABLE `perkes`
  MODIFY `idperkes` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tkj`
--
ALTER TABLE `tkj`
  MODIFY `idid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `tutor`
--
ALTER TABLE `tutor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
